"""Main module for running python -m bam.

Doesn't do much, except for printing general usage information.
"""

print("The 'bam' module cannot be run directly. The following subcommand is available:")
print()
print("python -m bam.pack")
