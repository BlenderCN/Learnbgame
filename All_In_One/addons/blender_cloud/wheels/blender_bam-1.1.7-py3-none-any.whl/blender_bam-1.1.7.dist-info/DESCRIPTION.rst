Bam Asset Manager is a tool to manage assets in Blender.


